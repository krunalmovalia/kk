<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\customercontroller;
use App\Models\customer; 
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::group(['prefix'=> '/customer'], function(){
    Route::get('/',[customercontroller::class ,"view"]);
    Route::get('/register' ,[customercontroller::class ,"create"])->name('customer.register'); 
    Route::post('/register' ,[customercontroller::class ,"customer"]); 
    Route::get('/delete/{id}' ,[customercontroller::class ,"delete"])->name('customer.delete');
    Route::get('/edit/{id}' ,[customercontroller::class ,"edit"])->name('customer.edit');
    Route::post('/update/{id}' ,[customercontroller::class ,"update"])->name('customer.update');
});
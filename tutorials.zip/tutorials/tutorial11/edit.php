<!DOCTYPE HTML>

<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Tutorial 12</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
	<body>
	<div class="row col-md-12">
							<div class="col-md-12">
								<div  style="border-color:  black;" class="panel panel-primary">
									<div class="panel-heading" style="background-color: black;">Update Info.</div>
									<div class="panel-body">

<?php
require "include/connection.php";

$n=@$_REQUEST['emailid'];
	$q="select * from registration where emailid='$n'";
	$res=mysqli_query($db,$q);
	while ($m=mysqli_fetch_array($res))
	{
		?>
<form method="post" action="update.php" name="RegForm"  class="form-horizontal ">
											


<div class="form-group">
<label class="col-sm-2 control-label">Name : </label>
<div class="col-sm-8">
<input type="text" name="Fname" id="fname" value="<?php echo $m[0];?>"  class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Email id : </label>
<div class="col-sm-8">
<input type="text" name="Email" value="<?php echo $m[3];?>" id="email"  class="form-control" readonly>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Contact No : </label>
<div class="col-sm-8">
<input type="text" name="Contact" id="contact" value="<?php echo $m[2];?>"  class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Address : </label>
<div class="col-sm-8">
    <input type="text" name="Address" value="<?php echo $m[4];?>"  id="paddress" class="form-control">
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label" for="name">Password :</label>
<div class="col-sm-8">
<input type="text" id="password" name="Pass" value="<?php echo $m[5];?>" class="form-control">
</div>
</div>



<div class="col-sm-6 col-sm-offset-4">
<input type="submit" name="submit" Value="Update" class="btn btn-primary">
</div>
</form>
<?php

	}
?>

									</div>
									</div>
								</div>
							</div>
						</div>
							</div>
						</div>
			
			

	</body>
</html>


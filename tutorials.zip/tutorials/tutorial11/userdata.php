<?php
require "include/connection.php";

// $k="create table registration(fullName varchar(500),gender varchar(250),contactno bigint(11),emailid varchar(500),address varchar(500),password varchar(20))";
// if(mysqli_query($con,$k))
// {
// echo"Table Registration Created";
// }
// else
// {
// echo"Error in Registration Table";
// }


$fullName=$_POST['Fname'];
$gender=$_POST['Gender'];
$contactno=$_POST['Contact'];
$email=$_POST['Email'];
$address=$_POST['Address'];
$password=$_POST['Pass'];

$query= "insert into registration values('$fullName','$gender','$contactno','$email','$address','$password');";

if(isset($_POST['submit']))
{	
mysqli_query($db,$query);
echo "<script>window.location='index.php';</script>";
}

?>
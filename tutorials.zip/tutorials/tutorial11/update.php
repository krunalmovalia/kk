<?php

require "include/connection.php";

 if (isset($_POST['submit'])) 
 {
    $fn=@$_POST['Fname'];
    $email=@$_POST['Email'];
	$phn=@$_POST['Contact'];
    $address=@$_POST['Address'];
    $pass=@$_POST['Pass'];

	$query="UPDATE registration set contactno='$phn',fullName='$fn', address='$address', password='$pass' where emailid='$email'";
 	if (mysqli_query($db,$query)) 
 	{
 		echo "<script>alert('Data Upadation Successfull !');
 		window.location='index.php';</script>";
 	}
 	else
 	{
 		echo "<script>alert('Data Upadation Failed !');
 		window.location='index.php';</script>";	
 	}
 }

?>
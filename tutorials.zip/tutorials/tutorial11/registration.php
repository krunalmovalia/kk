<!DOCTYPE HTML>

<html>
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Tutorial 11</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
	<body>
	<div class="row col-md-12">
							<div class="col-md-12">
								<div  style="border-color:  black;" class="panel panel-primary">
									<div class="panel-heading" style="background-color: black;">Fill all Info</div>
									<div class="panel-body">
<form method="post" action="userdata.php" name="RegForm" onsubmit="return myfunction()" class="form-horizontal ">
											


<div class="form-group">
<label class="col-sm-2 control-label">Name : </label>
<div class="col-sm-8">
<input type="text" name="Fname" id="fname"  class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Gender : </label>
<div class="col-sm-8">
<select name="Gender" class="form-control">
<option value="">Select Gender</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
<option value="Others">Others</option>
</select>
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Email id : </label>
<div class="col-sm-8">
<input type="text" name="Email" id="email"  class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Contact No : </label>
<div class="col-sm-8">
<input type="text" name="Contact" id="contact"  class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label">Address : </label>
<div class="col-sm-8">
<input type="text" name="Address" id="paddress" class="form-control">
</div>
</div>


<div class="form-group">
<label class="col-sm-2 control-label" for="name">Password :</label>
<div class="col-sm-8">
<input type="password" id="password" name="Pass"  class="form-control">
</div>
</div>

<div class="form-group">
<label class="col-sm-2 control-label" for="name">Confirm Password :</label>
<div class="col-sm-8">
<input type="password" id="cpass" name="Cpass"  class="form-control">
</div>
</div>	


<div class="col-sm-6 col-sm-offset-4">
<input type="reset" name="reset" Value="Reset" class="btn btn-primary">
<input type="submit" name="submit" Value="Register" class="btn btn-primary">
</div>
</form>

									</div>
									</div>
								</div>
							</div>
						</div>
							</div>
						</div>
			
			

	</body>
</html>

<script type="text/javascript">
	function myfunction()								 
{ 
	var  awe = /^[a-zA-Z]+$/;
	var  b = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
	var  c= /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$^+=!*()@%&]).{8,20}$/;
	
	var fn = document.forms["RegForm"]["Fname"];
	var gn = document.forms["RegForm"]["Gender"];
	var email = document.forms["RegForm"]["Email"];			 
	var contact = document.forms["RegForm"]["Contact"];			 		 			 
	var add = document.forms["RegForm"]["Address"];			 	 
	var password = document.forms["RegForm"]["Pass"]; 
	var cpassword = document.forms["RegForm"]["Cpass"];	

	// var func=fn.value;		 


	if (fn.value == "")								 
	{ 
		window.alert("Full Name Is Empty."); 
		fn.focus(); 
		return false; 
	}

	else if ((fn.value.length <= 3) || (fn.value.length > 15))
	{
		window.alert("First name must be 3 or less than 15."); 
		fn.focus(); 
		return false;
	}

	if (fn.value.match(awe)) 
	{
		gn.focus(); 
  		//return false;
    }
    else
    {
     alert("Please Enter values in Character only");
	 fn.focus();
     return false;
    }

	if (gn.value == "")								 
	{ 
		window.alert("Gender Is Empty."); 
		gn.focus(); 
		return false; 
	}

	if (email.value == "")								 
	{ 
		window.alert("Email Address is Empty."); 
		email.focus(); 
		return false; 
	}
	if(email.value.match(b))
	{
		contact.focus(); 
	} 
	else
	{
		window.alert("Please Enter Valid Email."); 
		email.focus();
		return false;
	}

	if (contact.value == "")								 
	{ 
		window.alert("Contact No Is Empty."); 
		contact.focus(); 
		return false; 
	}
	else if(isNaN(contact.value))
	{
		window.alert("Phone Number must be Number."); 
		contact.focus();
		return false; 			
	}
	else if(contact.value.length!=10)
	{
		window.alert("Phone Number must be 10 Digit."); 
		contact.focus(); 
		return false;

	}


	if (add.value == "")								 
	{ 
		window.alert("Address Is Empty."); 
		add.focus(); 
		return false; 
	}


	//password
	if(password.value =="")
	{
		window.alert("Password is Empty."); 
		password.focus(); 
		return false;
	}
	else if((password.value.length<=7) || (password.value.length>20))
	{
		window.alert("Password is must be 8 or less than 20."); 
		password.focus(); 		
		return false;
	}
	else
	{
		cpassword.focus();
	}
	
	//confirm password
	if(cpassword.value=="")
	{
		window.alert("Reenter Password Is Empty."); 
		cpassword.focus(); 		
		return false;
	}
	else if(cpassword.value != password.value)
	{
		window.alert("Reenter password is wrong."); 
		cpassword.focus(); 		
		return false;
	}
	else{
		//alert("Succesfully Register");

	}
}
</script>
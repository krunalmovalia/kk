<?php
session_start();

require "include/connection.php";
$id = isset($_GET['id'])?$_GET['id']:0;
echo $id;
$sql = "delete from registration where fullName = '$id'";
$result =$db->query($sql);
if($db->affected_rows)
{
    $_SESSION['deleteMsg'] = "Record Deleted Successfully!!!";
    print_r($_SESSION['deleteMsg']);
    header("location:index.php");
}
?>
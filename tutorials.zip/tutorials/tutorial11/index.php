<?php
  session_start();
  $deleteMsg = isset($_SESSION['deleteMsg'])?$_SESSION['deleteMsg']:"";
  unset($_SESSION['deleteMsg']);
?>
<html>
	<head> 
		<title>Registerd Data</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
        
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		 <script>
	   $("document").ready(function(){
            	$("a.delete").click(function(){
            		$(this).parents("tr").fadeOut();
;
            	});
            });
		</script>
		
		<style>
				
				body{
                    height: 100%;
                    display: flexbox;
                    justify-content: center;
                    align-items: center;
                    padding: 10px;
                    background-color:#0f0f0a;
					}
				.modal-content {
									margin: 5% auto 15% auto; 
									width:80%;
									border:8px solid whitesmoke;
								}
				.font{
						font-weight:bold;
					 }
				.bg{
					
                    background: linear-gradient(135deg, #71b7e6, #9b59b6);
					color:#1d1a1a;
					}
			
				
				.sr{
					background-color:#0f0f0a;
                    text-align: center;
                    color: whitesmoke;
					}
                    
                .tr{
                    text-align: center;
					}

				.txtalign{
					text-align: center;
				}
				table tr#ROW1  {background-color:black;
                    background: linear-gradient(135deg, #71b7e6, #9b59b6);
								}

                .backtosite{
                    color: whitesmoke;
                    font-size: large;
                }  
				.cl {
   					color:green;
					background-color: whitesmoke; 
}              
				
		</style>
	</head>
	<body>
	
	
		
	
		<table class="modal-content bg table table-condensed table-striped ">
		<h3 class="cl text-center"><?=$deleteMsg?></h3>
			<tr  id="ROW1">
				<td colspan="6"><h3 style="font-weight: bold;">Registerd Data</h3></td>
				<td style="padding: 20px; text-align: center;">
                <input type="submit" class="btn btn-primary w-25" onclick="location.href='registration.php'" value="Add Record">
            </td>
			</tr>
			<tr class="font sr">
				<th class="txtalign">Name</th>
				<th class="txtalign">Gender</th>
				<th class="txtalign">Contact No</th>
				<th class="txtalign">Email</th>
				<th class="txtalign">Address</th>
				<th class="txtalign">Password</th>
				<td class="txtalign">Manage</td>
        	</tr>
			<?php
			require "include/connection.php";
		
		$q="select * from registration";
		$r=mysqli_query($db,$q);
		while ($n=mysqli_fetch_array($r)) 
		{
			echo "<tr id='ROW1' class='tr'>";
			echo "<td>".$n[0]."</td>";
			echo "<td>".$n[1]."</td>";
			echo "<td>".$n[2]."</td>";
			echo "<td>".$n[3]."</td>";
			echo "<td>".$n[4]."</td>";
			echo "<td>".$n[5]."</td>";

			?>
			<td>
                <a href="delete.php?id=<?=$n[0]?>" class="delete"><button type="button" class="btn btn-danger">Delete</button></a></td>
			<?php
			echo "</tr>";
			

		}

		?>
		</table>

           <p class="backtosite"> <a href="../../index.html#tutorials" class="backtosite" >Back to Website !!!</a></p>

	</body>
</html>

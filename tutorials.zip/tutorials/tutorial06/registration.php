<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head> 
    <meta charset="UTF-8">
    <title>Registration</title>
    <link rel="stylesheet" href="../css/style.css">
     <meta name="viewport" content="width=device-width, initial-scale=1.0">
     
     <script>
       var countryStateInfo = {
    
	                      "India": {
                          "Gujarat": {
                                            "Rajkot" : ["360011", "360004"],
			                                      "Vadodara" : ["390011", "390020"],
			                                      "Surat" : ["395006", "395002"]
		                                        },
		                            "Assam": {
			                                    "Dispur": ["781005"],
			                                    "Guwahati" : ["781030", "781030"]
		                                      }
		                           
	                                }
                                }


window.onload = function () {
	
	//Get html elements
	var countySel = document.getElementById("countySel");
	var stateSel = document.getElementById("stateSel");	
	var citySel = document.getElementById("citySel");
	var zipSel = document.getElementById("zipSel");
	
	//Load countries
	for (var country in countryStateInfo) {
		countySel.options[countySel.options.length] = new Option(country, country);
	}
	
	//County Changed
	countySel.onchange = function () {
		 
		 stateSel.length = 1; // remove all options bar first
		 citySel.length = 1; // remove all options bar first
		 zipSel.length = 1; // remove all options bar first
		 
		 if (this.selectedIndex < 1)
			 return; // done
		 
		 for (var state in countryStateInfo[this.value]) {
			 stateSel.options[stateSel.options.length] = new Option(state, state);
		 }
	}
	
	//State Changed
	stateSel.onchange = function () {		 
		 
		 citySel.length = 1; // remove all options bar first
		 zipSel.length = 1; // remove all options bar first
		 
		 if (this.selectedIndex < 1)
			 return; // done
		 
		 for (var city in countryStateInfo[countySel.value][this.value]) {
			 citySel.options[citySel.options.length] = new Option(city, city);
		 }
	}
	
	//City Changed
	citySel.onchange = function () {
		zipSel.length = 1; // remove all options bar first
		
		if (this.selectedIndex < 1)
			return; // done
		
		var zips = countryStateInfo[countySel.value][stateSel.value][this.value];
		for (var i = 0; i < zips.length; i++) {
			zipSel.options[zipSel.options.length] = new Option(zips[i], zips[i]);
		}
	}	
}

     </script>
      <script src="../jquery/jquery-3.6.0.min.js"></script>
     	<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script> -->
       <script>
         $(document).ready(function() {
      
         $('#form').submit(function(e) {
         e.preventDefault();
       
         var fname = $('#fname').val();
         var email = $('#email').val();
         var password = $('#password').val();
         var repassword = $('#repassword').val();
         var age=$('#age').val();
         var birthdate=$('#birthdate').val();
         var state=$('#state').val();
         var country=$('#country').val();
         var city=$('#city').val();
         var note=$('#note').val();
         var imageUpload=$('#imageUpload').val();
         var countySel = $("#countySel").val();
         var stateSel = $("#stateSel").val();
         var citySel = $("#citySel").val();
         var zipSel = $("#zipSel").val();


         
         $(".error").remove();
      
         if (fname.length < 1) {
           $('#fname').after('<span class="error" style="color:red;">Full Name field is required</span>');
         }
        
             
         if (email.length < 1) {
           $('#email').after('<span class="error" style="color:red;">Email field is required</span>');
         } else {
         var regEx = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
         var validEmail = regEx.test(email);
         if (!validEmail) {
             $('#email').after('<span class="error" style="color:red;">Enter a valid email</span>');
         }
         }
         if (password.length < 8 ){
          $('#password').after('<span class="error" style="color:red;">Password must be at least 8 characters long</span>');
         }
         if (repassword.length < 8) {
         $('#repassword').after('<span class="error" style="color:red;">Password must be at least 8 characters long</span>');
         }
         else if(password!=repassword)
         {
           $('#repassword').after('<span class="error" style="color:red;">Password dose not match</span>');
         }
         if (age.length < 1) {
         $('#age').after('<span class="error" style="color:red;">Age field is required</span>');
         }
         if (birthdate.length < 1) {
         $('#birthdate').after('<span class="error" style="color:red;">Birthdate field is required</span>');
         }
        
         
         if (countySel == "") {
         $('#countySel').after('<span class="error" style="color:red;">Country field is required</span>');
         }
         if (stateSel == "") {
         $('#stateSel').after('<span class="error" style="color:red;">State field is required</span>');
         }
         if (citySel == "") {
         $('#citySel').after('<span class="error" style="color:red;">City field is required</span>');
         }
         if (zipSel == "") {
         $('#zipSel').after('<span class="error" style="color:red;">Zipcode field is required</span>');
         }
         if (imageUpload.length < 1) {
         $('#imageUpload').after('<span class="error" style="color:red;">Image Upload field is required</span>');
         }

         if (note.length < 1) {
         $('#note').after('<span class="error" style="color:red;">Note field is required</span>');
         }
        

         });   
        
       });
       </script>
   </head>
<body>
  <div class="container">
    <div class="title">Registration</div>
    <div class="content">
      <form action="#" method="post" id="form">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Full Name</span>
            <input type="text" placeholder="Enter your name" id="fname">
          </div>
          
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" placeholder="Enter your email" id="email">
          </div>
         
          <div class="input-box">
            <span class="details">Password</span>
            <input type="password" placeholder="Enter your password" id="password" >
          </div>
          <div class="input-box">
            <span class="details">Confirm Password</span>
            <input type="text" placeholder="Confirm your password" id="repassword" >
          </div>
        
          <div class="input-box">
            <span class="details">Age</span>
            <input type="number" placeholder="Enter your age" id="age">
          </div>

          <div class="input-box">
            <span class="details">Birthdate</span>
            <input type="date" placeholder="Enter your birthdate" id="birthdate">
          </div>

          <div class="input-box">
            <span class="details">Select Country, State & City</span>
            <select name='item'  id="countySel" size="1">
              <option value="" selected="selected" id="country">-- Select Country --</option>
          </select>
          <select id="stateSel" size="1">
            <option value="" selected="selected" id="state">-- Select State--</option>
        </select>
        <select id="citySel" size="1">
          <option value="" selected="selected" id="city">-- Select City--</option>
      </select>

      <select id="zipSel" size="1">
        <option value="" selected="selected">-- Select Zip--</option>
    </select>
          </div>

          <div class="input-box" >
            <span class="details">Profile Picture</span>
            
             <input id="imageUpload" type="file" 
                    name="profile_photo" placeholder="Photo" capture>
            
          </div>

      
          <div class="input-box">
            <span class="details">Note</span>
            <input type="text" id="note" placeholder="Write Something..." >
            
          </div>

        </div>
       
        <div class="button">
          <input type="submit" value="Register">
        </div>

        <div class="signup-image">
          <a href="login.php" class="signup-image-link">I am already member</a>
      </div>
      <div class="signup-image">
        <a href="../../index.html#tutorials" text-align="center" class="signup-image-link">Back to Website !!!</a>
    </div>

      </form>
    </div>
  </div>

</body>
</html>

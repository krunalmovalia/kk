<?php session_start(); /* Starts the session */
/* Check Login form submitted */	
if(isset($_POST['Submit'])){ 
    
    /* Check and assign submitted Username and Password to new variable */
    $Username = (isset($_POST['Username']) ? trim($_POST['Username']) : '');
    $Password = (isset($_POST['Password']) ? trim($_POST['Password']) : '');
    
    /* Check Username and Password existence in defined array */		
    if ($Username == 'krunal@gmail.com' && $Password == '123456'){
        /* Success: Set session variables and redirect to Protected page  */
        $_SESSION['Username']=$Username;
        header('location:index.php');
    } 
    else {
       echo '<script>alert("Email & Password is Incorrect !");</script>';
       echo '<script type="text/javascript">';
       echo 'window.location.href="index.php";';
       echo '</script>';
       }
}
?>
<?php session_start(); /* Starts the session */
unset($_SESSION['Username']);
$_SESSION['logoutmsg'] = 'Logout Successfully';
header("location:index.php");
exit;
?>
 
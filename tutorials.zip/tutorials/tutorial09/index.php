<?php
require "include/connection.php";
?>
<html>
    <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutorial09</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <link rel="stylesheet" href="../css/style.css">
    </head>
    <body>
    <div class="container">
	<h1><b><i>Well Done!</i></b></h1><br>
	<div class="alert alert-success" >
    <p class="text-uppercase">
                <?php
            if($db -> connect_errno)
            {
                echo $db->connect_error;
            }
            else
            {
                echo "Connection Done !";
            }
                ?>
            </p>
        <hr>
            <p class="mb-0">You're successfully connected to the database.</p>
	</div>
    <div class="signup-image">
        <a href="../../index.html#tutorials" text-align="center" class="signup-image-link">Back to Website !!!</a>
    </div>
</div>
    </body> 
</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Months Name </title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<?php
	$monthno=$_POST['month'];
?>
<div class="container">
	<h1><b><i> Month No is : <?php echo $monthno; ?> </i></b></h1><br>
	<div class="form-group"  >
		<select id="month" name="month" class="form-control" required>
			<option <?php if($monthno==1) echo "selected" ?>>January</option>
			<option <?php if($monthno==2) echo "selected" ?>>Febuary</option>
			<option <?php if($monthno==3) echo "selected" ?>>March</option>
			<option <?php if($monthno==4) echo "selected" ?>>April</option>
			<option <?php if($monthno==5) echo "selected" ?>>May</option>
			<option <?php if($monthno==6) echo "selected" ?>>June</option>
			<option <?php if($monthno==7) echo "selected" ?>>July</option>
			<option <?php if($monthno==8) echo "selected" ?>>August</option>
			<option <?php if($monthno==9) echo "selected" ?>>September</option>
			<option <?php if($monthno==10) echo "selected" ?>>October</option>
			<option <?php if($monthno==11) echo "selected" ?>>November</option>
			<option <?php if($monthno==12) echo "selected" ?>>December</option>
		</select>
	</div>
    <div class="signup-image">
        <a href="index.html" text-align="center" class="signup-image-link">Want to Select more..</a>
    </div>
    <div class="signup-image">
        <a href="../../index.html#tutorials" text-align="center" class="signup-image-link">Back to Website !!!</a>
    </div>
</div>
</body>
</html>
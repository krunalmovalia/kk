
<!DOCTYPE html>
<html> 
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- For favicon png -->
	        <link rel="shortcut icon" type="image/icon" href="logo/favicon.png"/>
    <title>Interest Calculation</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body >
    <div class="container">
        <form action="result.php" method="post">
            <div class="details">
                   <h1><b>Calculate Simple Interest</b></h1>
            </div>
            <div class="form-group">
                <input type="number" class="form-control item" name="amount" placeholder="Enter Principal Amount" required>
            </div>
            <div class="form-group">
                <input type="number" class="form-control item" name="rate" placeholder="Enter Rate of Interest" required>
            </div>
              <div class="form-group">
                <input type="number" class="form-control item" name="year" placeholder="Enter Number of Years" required>
            </div>
            <div class="button">
                <div class="col-md-12">
                    <input type="submit" name="calculate" value="Calculate" class="btn btn-info"/>
                </div>
            </div>
            <div class="signup-image">
        <a href="../../index.html#tutorials" text-align="center" class="signup-image-link">Back to Website !!!</a>
    </div>
        </form>
    </div>
</body>
</html>


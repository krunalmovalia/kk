
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
                <!-- For favicon png -->
	        <link rel="shortcut icon" type="image/icon" href="logo/favicon.png"/>
		<title>Interest Calculation</title>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/style.css"> 
	</head>
	<body>

	<div class="container">
        <form>
            <div class="details">
                   <h1><b>Simple Interest -- Result </b></h1>
            </div>
		<div class="user-details">
          <div class="input-box">
            <span class="details">Principal value : <?php   $amount=$_POST['amount']; echo $amount; ?></span>
          </div>

		  <div class="input-box">
            <span class="details">Rate of interest : <?php   $rate=$_POST['rate']; echo $rate; ?></span>
          </div>

		  <div class="input-box">
            <span class="details">Number of Month : <?php   $year=$_POST['year']; echo $year; ?></span>
          </div>
		 
		  <div class="input-box">
            <span class="details"><b>Simple interest is : <?php  $result=$amount*$rate*$year/100;   echo $result; ?></b></span>
          </div>
          <div class="signup-image">
        <a href="index.php" text-align="center" class="signup-image-link">Want to Calculate more..</a>
    </div>
        </form>
        <div class="signup-image">
        <a href="../../index.html#tutorials" text-align="center" class="signup-image-link">Back to Website !!!</a>
    </div>
    </div>
       
	
	</body>
</html>
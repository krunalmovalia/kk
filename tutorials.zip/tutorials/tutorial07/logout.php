<?php session_start(); /* Starts the session */
unset($_SESSION['Username']);
$_SESSION['logoutmsg'] = 'Logout Successfully';
if(isset($_COOKIE['Username']) && isset($_COOKIE['Password']))
{
    $Username = $_COOKIE['Username'];
    $Password = $_COOKIE['Password'];
   
}
header("location:index.php");
exit;
?>
 
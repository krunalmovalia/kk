<?php session_start(); /* Starts the session */
	if(!isset($_SESSION['Username']))
	{
	header('location:login.php');
	}
	
?>
<html>
	<head> 
		<title>Registerd Data</title>
		
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
        
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
		 <script>
	   $("document").ready(function(){
            	$("a.delete").click(function(){
            		$(this).parents("tr").fadeOut();
;
            	});
            });
		</script>
		
		<style>
				
				body{
                    height: 100%;
                    display: flexbox;
                    justify-content: center;
                    align-items: center;
                    padding: 10px;
                    background-color:#0f0f0a;
					}
				.modal-content {
									margin: 5% auto 15% auto; 
									width:80%;
									border:8px solid whitesmoke;
								}
				.font{
						font-weight:bold;
					 }
				.bg{
					
                    background: linear-gradient(135deg, #71b7e6, #9b59b6);
					color:#1d1a1a;
					}
			
				
				.sr{
					background-color:#0f0f0a;
                    text-align: center;
                    color: whitesmoke;
					}
                    
                .tr{
				
                    text-align: center;
					}
				table tr#ROW1  {background-color:black;
                    background: linear-gradient(135deg, #71b7e6, #9b59b6);
								}

                .backtosite{
                    color: whitesmoke;
                    font-size: large;
                }                
				
		</style>
	</head>
	<div>
	<body>
		<table class="modal-content bg table table-condensed table-striped ">
			<tr  id="ROW1">
				<td colspan="7"><h3 style="font-weight: bold;">Registerd Data</h3></td>
				<td style="padding: 20px; text-align: center;">
                <input type="submit" class="btn btn-primary w-25" value="Add Record">
				<input type="button" class="btn btn-danger w-25" onclick="location.href='logout.php'" style='margin-lift:8px;' value="Logout">
            </td>
                

			</tr>
			<tr class="font sr">
				<td>Sr. no</td>
				<td>Name</td>
				<td>Username</td>
				<td>Password</td>
				<td>Age</td>
				<td>City</td>
				<td>Country</td>
				<td>Manage</td>
			</tr>
			<tr id="ROW1" class="tr">
				<td>1</td>
				<td>Krunal Movalia</td>
				<td>kmovalia383@rku.ac.in</td>
				<td>123456</td>
				<td>21</td>
				<td>Rajkot</td>
				<td>India</td>
				<td><a href="#"><button type="button" class="btn btn-info">Edit</button> </a>
                <a href="#" class="delete"><button type="button" class="btn btn-danger">Delete</button></a></td>
			</tr>
			<tr class="tr">
				<td>2</td>
				<td>Jainil Mayani</td>
				<td>jmayani@rku.ac.in</td>
				<td>985563</td>
				<td>20</td>
				<td>Junagadh</td>
				<td>India</td>
				<td><a href="#"><button type="button" class="btn btn-info">Edit</button> </a>
                <a href="#" class="delete"><button type="button" class="btn btn-danger">Delete</button></a></td>
			</tr>
			<tr class="tr" id="ROW1">
				<td>3</td>
				<td>Prakash Dhankecha</td>
				<td>pdhankecha@rku.ac.in</td>
				<td>445635</td>
				<td>20</td>
				<td>Rajkot</td>
				<td>India</td>
				<td><a href="#"><button type="button" class="btn btn-info">Edit</button> </a>
                <a href="#" class="delete"><button type="button" class="btn btn-danger">Delete</button></a></td>
			</tr>
			<tr class="tr">
				<td>4</td>
				<td>Nihar Savaliya</td>
				<td>nsavaliya@rku.ac.in</td>
				<td>989565</td>
				<td>19</td>
				<td>Junagadh</td>
				<td>India</td>
				<td><a href="#"><button type="button" class="btn btn-info">Edit</button> </a>
                <a href="#" class="delete"><button type="button" class="btn btn-danger">Delete</button></a></td>
			</tr>
			<tr class="tr" id="ROW1">
				<td>5</td>
				<td>Om Thanki</td>
				<td>othanki@rku.ac.in</td>
				<td>596886</td>
				<td>19</td>
				<td>Div</td>
				<td>India</td>
				<td><a href="#"><button type="button" class="btn btn-info">Edit</button> </a>
                <a href="#" class="delete"><button type="button" class="btn btn-danger">Delete</button></a></td>
			</tr>
			
		</table>
        
           <p class="backtosite"> <a href="../../index.html#tutorials" class="backtosite" >Back to Website !!!</a></p>
    
		</div>
	</body>
</html>


<?php
session_start();
$logoutMsg = isset($_SESSION['logoutmsg']) ? $_SESSION['logoutmsg'] : "";
unset($_SESSION['logoutmsg']);
?>
<?php

$user = isset($_COOKIE['Username']) ? $_COOKIE['Username'] : "";
$pass = isset($_COOKIE['Password']) ? $_COOKIE['Password'] : "";
$setcheckbox = isset($_COOKIE['Username']) ? 'checked' : "";

?>
<!DOCTYPE html>
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <link rel="stylesheet" href="../css/style.css">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="../jquery/jquery-3.6.0.min.js"></script>

  <script>
    $(document).ready(function() {

      $('#form').submit(function() {
        $('.error').remove();
        var username = $('#Username').val();

        var password = $('#Password').val();

        if (username == "" || password == "") {
          if (username == "")
            $('#Username').after('<span class="error" style="color:red;">This Username field is required</span>');
          if (password == "")
            $('#Password').after('<span class="error" style="color:red;">This Password field is required</span>');
          return false;
        }
      });

    });
  </script>

</head>

<body>
  <div class="container">
    <div class="title">Login</div>
    <h4 class="text-success text-center"><?= $logoutMsg ?></h4>
    <div class="content">
      <form action="validateuser.php" method="post" id="form">
        <div class="user-details">

          <div class="input-box">
            <span class="details">Username</span>
            <input type="text" placeholder="krunal@gmail.com" name="Username" id="Username" value=<?= $user ?>>
          </div>

          <div class="input-box">
            <span class="details">Password</span>
            <input type="password" placeholder="123456" name="Password" id="Password" value=<?= $pass ?>>
          </div>

          <div class="form-group form-check">
            <input type="checkbox" name="remember" class="form-check-input" <?= $setcheckbox ?> id="Remember">
            <label class="form-check-label" for="remember-me">Remember Me. </label>
          </div>


        </div>

        <div class="button">
          <input type="submit" id="login" name="Submit" value="Login">
        </div>

        <div class="signup-image">
          <a href="registration.php" text-align="center" class="signup-image-link">Don't have Account</a>
        </div>
        <div class="signup-image">
          <a href="../../index.html#tutorials" text-align="center" class="signup-image-link">Back to Website !!!</a>
        </div>

      </form>
    </div>
  </div>

</body>

</html>
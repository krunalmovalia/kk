<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tutorial 8</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
<div class="container">
    <?php if(isset($_GET['error'])){?>
        <p style="color:red"> <?php echo $_GET['error']; ?></p>
        <?php } ?>
        <form action="upload.php" method="POST" enctype="multipart/form-data">
            <h1><b><i> Select Picture. </i></b></h1><br>
            <div class="form-group">
                <div class="col-md-12">
                    <input type="file" name="my_image"/>
                </div>
            </div>
            <div class="button">
                <div class="col-md-12">
                    <input type="submit" class="btn btn-info" name="submit" value="Upload"/>
                </div>
                </div>
                <div class="col-md-12">
                <p class="backtosite"> <a href="view.php" class="backtosite" >Want to View Photos.</a></p>
                <p><a href="../../index.html#tutorials" text-align="center" class="signup-image-link">Back to Website !!!</a></p>
                </div>
            
    
        </form>
</div>
    
</body>
</html>
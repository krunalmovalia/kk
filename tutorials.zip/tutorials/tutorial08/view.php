<?php  require "include/connection.php"; ?>
<!DOCTYPE html>
<html lang="en"> 
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Pictures</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .alb{
            width: 200px;
            height: 200px;
            padding: 5px;
        }
        .img{
            width: 200px;
            height: 150px;
        }
        a{
            text-decoration:none;
            color:black;
            
        }
        .backtosite{
                    color: blue;
                    font-size: large;
                }           
    </style>
</head>
<body><div class="container">
<div class="title mb-2">Tutorial 08</div>
<table id="example" class="table table-striped table-bordered" style="width:100%">
        <tr>
            <th>ID</th>
            <th>Pictures</th>
        </tr>

    <?php
        $sql = "SELECT * FROM images ORDER BY id DESC";
        $result = mysqli_query($db, $sql);

if($result->num_rows > 0){ ?> 
   
        <?php while($row = $result->fetch_assoc()){  
            ?>
            <tr>
                <td align="center"><?=$row["id"]?></td>
                <td align="center"><img class="img" src="uploads/<?=$row['image_url']?>"></td>
            </tr>
        <?php } ?> 
  
<?php }else{ ?> 
    <p class="status error">Image(s) not found...</p> 
<?php } ?>
     </table>
     <p class="backtosite"> <a href="index.php" class="backtosite" >&#8592; Want to Upload more Photos?</a></p>
</div>
       

</body>
</html>